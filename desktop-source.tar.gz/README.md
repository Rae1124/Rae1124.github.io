# Online Students ID Replacement System

The repository contains the production GitHub Pages client and a Windows Electron desktop client that uses the same Supabase backend.

## Desktop versions

Two Windows 10/11 x64 packages are produced:

- **Online-Students-ID-Replacement-System-Setup.exe** — standard NSIS installer with Start Menu and Desktop shortcuts.
- **Online-Students-ID-Replacement-System-Portable.exe** — runs without installation.

The desktop interface is bundled locally inside Electron. Internet access is still required for authentication, Supabase data, uploads, document viewing, notifications, and Cloudflare Turnstile staff verification.

## Development

Requirements: Node.js 20+.

```text
npm install
npm test
npm run prepare:icon
npm start
```

Build Windows packages on Windows:

```text
npm run build:win
```

## Staff CAPTCHA

Student login does not use CAPTCHA. Registrar, ID Office, and Administrator login opens a locked-down verification window at `https://rae1124.github.io/desktop-captcha.html`. The short-lived Turnstile token is held only in memory and is still validated server-side by the existing Supabase staff-login function.

## GitHub Actions build

The **Build Windows Desktop App** workflow runs the tests and packages both `.exe` files on `windows-latest`. Download the `online-students-id-replacement-system-windows` artifact from the successful workflow run.

## Security notes

The desktop package contains no Supabase service-role key and no Turnstile secret. The Electron renderer has Node integration disabled, context isolation enabled, and network/API access is restricted through the preload/main-process bridge. Signed document URLs are allowed only for the existing private Supabase storage host/path.
